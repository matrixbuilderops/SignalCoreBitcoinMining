# Copyright 2020-2024 Lynn Root
"""Explain yourself! Interrogate a codebase for docstring coverage."""
__author__ = "Lynn Root"
__version__ = "1.7.0"
__email__ = "lynn@lynnroot.com"
__description__ = "Interrogate a codebase for docstring coverage."
__uri__ = "https://interrogate.readthedocs.io"
