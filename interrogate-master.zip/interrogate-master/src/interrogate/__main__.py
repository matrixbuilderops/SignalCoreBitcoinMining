# Copyright 2020-2024 Lynn Root
"""interrogate entrypoint"""

from interrogate import cli


if __name__ == "__main__":
    cli.main()
