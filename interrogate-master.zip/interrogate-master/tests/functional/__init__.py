# Copyright 2020-2024 Lynn Root
"""Yay functional tests for the ``interrogate`` package!"""
