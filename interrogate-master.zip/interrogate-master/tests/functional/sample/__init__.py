# Copyright 2020-2024 Lynn Root
"""Some init module docs"""
