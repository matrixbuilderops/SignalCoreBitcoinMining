# Copyright 2020-2024 Lynn Root
"""Yay unit tests for the ``interrogate`` package!"""
