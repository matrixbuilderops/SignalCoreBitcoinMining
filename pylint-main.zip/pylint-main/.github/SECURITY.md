Coordinated Disclosure Plan: https://tidelift.com/security
