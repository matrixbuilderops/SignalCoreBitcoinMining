import sys

if __name__ == "__main__":
    user = input("Enter user name: ")
    print(f"Hello, {user}")
    sys.exit(0)
