x = 1
x = x + 1  # [consider-using-augmented-assign]
