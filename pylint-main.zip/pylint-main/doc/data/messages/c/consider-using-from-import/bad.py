import os.path as path  # [consider-using-from-import]
