seasons = ["Spring", "Summer", "Fall", "Winter"]

for i in range(len(seasons)):  # [consider-using-enumerate]
    print(i, seasons[i])
