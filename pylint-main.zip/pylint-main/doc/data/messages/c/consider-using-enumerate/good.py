seasons = ["Spring", "Summer", "Fall", "Winter"]

for i, season in enumerate(seasons):
    print(i, season)
