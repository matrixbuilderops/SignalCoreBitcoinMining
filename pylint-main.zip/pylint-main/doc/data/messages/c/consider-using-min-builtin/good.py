print(min(1, 2))
