FELIDAES = {  # [consider-using-namedtuple-or-dataclass]
    "The queen's cymric, fragile furry friend": {
        "tail_length_cm": 1,
        "paws": 4,
        "eyes": 2,
        "Elizabethan collar": 1,
    },
    "Rackat the red, terror of the sea": {
        "tail_length_cm": 13,
        "paws": 3,
        "eyes": 1,
        "Red Hat": 1,
    },
}
