knights = {"Gallahad": "the pure", "Robin": "the brave"}

description = knights.get("Gallahad", "")
