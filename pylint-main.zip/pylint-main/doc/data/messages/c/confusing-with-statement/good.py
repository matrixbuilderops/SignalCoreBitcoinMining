with open("file.txt", "w", encoding="utf8") as fh1:
    with open("file.txt", "w", encoding="utf8") as fh2:
        pass
