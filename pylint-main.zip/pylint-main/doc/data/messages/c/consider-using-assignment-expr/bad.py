apples = 2

if apples:  # [consider-using-assignment-expr]
    print("God apples!")
