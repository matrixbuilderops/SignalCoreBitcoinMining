NUMBERS = [1, 2, 2, 3, 4, 4]

UNIQUE_EVEN_NUMBERS = {number for number in NUMBERS if number % 2 == 0}
