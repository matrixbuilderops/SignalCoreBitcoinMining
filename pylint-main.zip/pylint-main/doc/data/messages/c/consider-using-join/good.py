print("".join(["apple", "pear", "peach"]))
