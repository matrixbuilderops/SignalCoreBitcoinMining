import typing

cats: typing.cast(dict[str, int], "string")
