def is_the_answer(meaning_of_life: int) -> bool:
    return meaning_of_life == 42
