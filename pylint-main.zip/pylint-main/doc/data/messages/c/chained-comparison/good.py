a = int(input())
b = int(input())
c = int(input())
if a < b < c:
    pass
