def fruit_is_round(fruit):
    return fruit in {"apple", "orange", "melon"}
