with open("apple.txt", "r", encoding="utf8") as file:
    contents = file.read()
