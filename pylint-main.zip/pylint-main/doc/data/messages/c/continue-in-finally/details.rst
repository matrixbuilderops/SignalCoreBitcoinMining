Note this message can't be emitted when using Python version 3.8 or greater.
