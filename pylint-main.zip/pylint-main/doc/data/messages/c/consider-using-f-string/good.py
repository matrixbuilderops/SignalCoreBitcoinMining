menu = ("eggs", "spam", 42.4)

f_string_order = f"{menu[0]} and {menu[1]}: {menu[2]:0.2f} ¤"
