class Wolf:
    @staticmethod
    def eat(self):  # [bad-staticmethod-argument]
        pass
