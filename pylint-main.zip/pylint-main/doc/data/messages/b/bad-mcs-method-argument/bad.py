class Meta(type):
    def func(some):  # [bad-mcs-method-argument]
        pass
