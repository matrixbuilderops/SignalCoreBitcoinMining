class Meta(type):
    def func(cls):
        pass
