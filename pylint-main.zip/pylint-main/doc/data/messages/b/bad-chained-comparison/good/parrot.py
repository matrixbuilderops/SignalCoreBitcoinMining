shop = {
    # animal: (specie, descriptions)
    "parrot": ("Norvegian blue", ("restin'", "remarkable", "beautiful plumage")),
}

if "parrot" in shop and "restin'" in shop["parrot"][1]:
    print("Hellooooo, Pooolllllyyy ! WAAAAKEEY, WAKKEEEY !")
