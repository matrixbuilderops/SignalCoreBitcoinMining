def foo():  # [bad-docstring-quotes]
    "Docstring."
    return
