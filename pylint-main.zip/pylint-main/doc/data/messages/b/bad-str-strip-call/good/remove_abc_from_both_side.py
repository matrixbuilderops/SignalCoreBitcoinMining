"abcbc def bacabc".strip("abc ")
# >>> 'def'
