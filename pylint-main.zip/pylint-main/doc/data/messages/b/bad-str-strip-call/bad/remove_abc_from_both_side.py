"abcbc def bacabc".strip("abcbc ")  # [bad-str-strip-call]
# >>> 'def'
