print("%d" % "1")  # [bad-string-format-type]
