try:
    print(int(input()))
except TypeError:
    raise
except Exception:
    raise
