# +1: [bidirectional-unicode]
example = "x‏" * 100  #    "‏x" is assigned
