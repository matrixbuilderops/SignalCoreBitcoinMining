print("%(one)d" % {"one": 1, 2: 2})  # [bad-format-string-key]
