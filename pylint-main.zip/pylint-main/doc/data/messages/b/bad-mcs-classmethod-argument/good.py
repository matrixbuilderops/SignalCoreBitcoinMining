class Meta(type):
    @classmethod
    def foo(mcs):
        pass
