class Meta(type):
    @classmethod
    def foo(some):  # [bad-mcs-classmethod-argument]
        pass
