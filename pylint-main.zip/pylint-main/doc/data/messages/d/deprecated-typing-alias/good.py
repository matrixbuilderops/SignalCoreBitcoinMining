item_to_number_of_item: dict[str, int]
