test_score = {"Mathematics": 85, "Biology": 90, "History": 75}
