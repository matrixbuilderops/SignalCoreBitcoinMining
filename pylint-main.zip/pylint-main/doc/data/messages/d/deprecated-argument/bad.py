int(x=1)  # [deprecated-argument]
