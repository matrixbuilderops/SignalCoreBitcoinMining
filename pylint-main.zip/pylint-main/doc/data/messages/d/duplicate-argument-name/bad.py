def get_fruits(apple, banana, apple):  # [duplicate-argument-name]
    pass
