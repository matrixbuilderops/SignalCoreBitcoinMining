def whats_on_the_telly(penguin=[]):  # [dangerous-default-value]
    penguin.append("property of the zoo")
    return penguin
