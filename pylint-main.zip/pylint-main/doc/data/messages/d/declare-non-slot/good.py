class Student:
    __slots__ = ("name", "surname")

    name: str
    surname: str
