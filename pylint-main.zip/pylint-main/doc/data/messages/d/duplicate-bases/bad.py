class Animal:
    pass


class Cat(Animal, Animal):  # [duplicate-bases]
    pass
