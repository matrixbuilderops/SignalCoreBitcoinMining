correct_set = {"value1", 23, 5}
