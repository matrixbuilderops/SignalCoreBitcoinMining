try:
    1 / 0
except ZeroDivisionError:
    pass
except ZeroDivisionError:  # [duplicate-except]
    pass
