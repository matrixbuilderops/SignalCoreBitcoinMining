print("%(x)d %(y)d" % [1, 2])  # [format-needs-mapping]
