print("%(x)d %(y)d" % {"x": 1, "y": 2})
