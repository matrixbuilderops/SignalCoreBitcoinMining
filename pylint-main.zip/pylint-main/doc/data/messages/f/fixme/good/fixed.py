# The issue was fixed: no longer need the comment
