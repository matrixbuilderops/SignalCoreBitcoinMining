There's no checks at all for a file if it starts by ``# pylint: skip-file``.
