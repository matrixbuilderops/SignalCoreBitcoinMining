def add(x, y):
    return x + y


value = add(10, 10)
