cherries = 10
eaten_cherries = 2
cherries -= eaten_cherries
