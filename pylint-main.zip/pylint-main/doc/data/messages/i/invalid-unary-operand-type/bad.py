cherries = 10
eaten_cherries = int
cherries = -eaten_cherries  # [invalid-unary-operand-type]
