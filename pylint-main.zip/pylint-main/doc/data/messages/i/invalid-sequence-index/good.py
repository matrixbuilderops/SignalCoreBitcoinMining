fruits = ["apple", "banana", "orange"]
print(fruits[0])
