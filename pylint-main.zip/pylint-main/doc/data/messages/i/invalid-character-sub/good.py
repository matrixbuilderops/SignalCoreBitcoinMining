STRING = "Valid character sub x1A"
