__all__ = ("CONST",)

CONST = 42
