STRING = "Invalid escape character "  # [invalid-character-esc]
