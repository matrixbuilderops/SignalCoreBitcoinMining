STRING = "Valid escape character \x1b"
