*fruit = ["apple", "banana", "orange"]  # [invalid-star-assignment-target]
