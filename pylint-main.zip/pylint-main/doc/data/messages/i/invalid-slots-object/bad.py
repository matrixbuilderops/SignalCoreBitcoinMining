class Person:
    __slots__ = ("name", 3)  # [invalid-slots-object]
