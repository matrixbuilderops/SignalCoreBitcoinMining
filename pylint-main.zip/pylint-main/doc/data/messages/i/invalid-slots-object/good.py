class Person:
    __slots__ = ("name", "surname")
