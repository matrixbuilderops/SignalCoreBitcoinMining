with open("hello.txt" "r") as f:  # [implicit-str-concat]
    print(f.read())
