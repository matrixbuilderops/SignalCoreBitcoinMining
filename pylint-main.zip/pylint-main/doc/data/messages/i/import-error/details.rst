This can happen if you're importing a package that is not installed in your environment, or if you made a typo.

The solution is to install the package via pip/setup.py/wheel or fix the typo.
