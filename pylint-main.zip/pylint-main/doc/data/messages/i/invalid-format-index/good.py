enough_fruits = ["apple", "banana"]
print("The second fruit is a {fruits[1]}".format(fruits=enough_fruits))
