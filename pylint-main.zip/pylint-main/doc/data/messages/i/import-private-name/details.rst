Using private imports expose you to unexpected breaking changes for any version
bump of your dependencies, even in patch versions.
