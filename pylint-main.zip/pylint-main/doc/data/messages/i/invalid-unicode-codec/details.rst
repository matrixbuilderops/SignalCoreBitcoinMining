This message is a placeholder for a potential future issue with unicode codecs.
