class CustomBool:
    """__bool__ returns `bool`"""

    def __bool__(self):
        return True
