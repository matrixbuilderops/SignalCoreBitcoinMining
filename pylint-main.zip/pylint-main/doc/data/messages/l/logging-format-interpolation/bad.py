import logging
import sys

# +1: [logging-format-interpolation]
logging.error("Python version: {}".format(sys.version))
