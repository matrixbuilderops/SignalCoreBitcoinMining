import logging
import sys

logging.warning("Python version: %", sys.version)  # [logging-format-truncated]
