def is_an_orange(fruit):
    return fruit is "orange"  # [literal-comparison]
