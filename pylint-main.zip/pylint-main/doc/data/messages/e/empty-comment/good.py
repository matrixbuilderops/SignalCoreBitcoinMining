# comment

x = 0  # comment
