# +1:[empty-comment]
#

# +1:[empty-comment]
x = 0  #
