from vulture.core import Vulture
from vulture.version import __version__

assert __version__
assert Vulture
