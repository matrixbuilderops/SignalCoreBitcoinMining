import enum


class EnumWhitelist(enum.Enum):
    EnumWhitelist = 1


# Special attributes used by enum classes.
EnumWhitelist.EnumWhitelist._name_
EnumWhitelist.EnumWhitelist._value_
