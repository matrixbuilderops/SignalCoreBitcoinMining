from unittest import TestCase, mock

TestCase.setUp
TestCase.tearDown
TestCase.setUpClass
TestCase.tearDownClass
TestCase.run
TestCase.skipTest
TestCase.debug
TestCase.failureException
TestCase.longMessage
TestCase.maxDiff
TestCase.subTest

mock.Mock.return_value
mock.Mock.side_effect

mock.MagicMock.return_value
mock.MagicMock.side_effect
