import pint

ureg = pint.UnitRegistry()
ureg.default_format
