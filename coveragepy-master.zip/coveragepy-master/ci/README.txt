Files to support continuous integration systems.
